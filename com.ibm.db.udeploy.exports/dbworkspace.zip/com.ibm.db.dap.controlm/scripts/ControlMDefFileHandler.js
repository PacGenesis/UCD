   // spanDir - a directory traversal function for
   // Rhino JavaScript
   // Copyright 2010 by James K. Lawless
   // See MIT/X11 license at 
   // http://www.mailsend-online.com/wp/license.php

importPackage(java.io);

	function ControlMDefFileHandler(dir, userName, password, hostName, cmdName) {
		this.dir = dir;
		this.userName = userName;
		this.password = password;
		this.hostName = hostName;
		this.cmdName = cmdName;
	}
      // spanDir() accepts two parameters
      // The first is a string representing a directory path
      // The second is a closure that accepts a parameter of type
      // java.io.File
	ControlMDefFileHandler.prototype = {
		  process : function() {
			  this.spanDir(this.dir);
		  },
		  spanDir : function(adir) {
		      var lst=new File(adir).listFiles();
		      var i;
		      for(i=0;i<lst.length;i++) {
		            // If it's a directory, recursive call spanDir()
		            // so that we end up doing a scan of
		            // the directory tree
		         if(lst[i].isDirectory()) {
		            this.spanDir(lst[i].getAbsolutePath());
		         }
		            // Pass the File object to the handler that
		            // the caller has specified regardless of whether
		            // the File object is a directory.
		         this.processXml(lst[i]);
		      }
		   },
		   processXml : function(fil) {
		     var nam;
		      nam=fil.getAbsolutePath();
		      if(!fil.isDirectory()) {
		         if(nam.toLowerCase().endsWith(".xml")) {
		            this.executeUpdateDef(nam); 
		         }
		      }
			   
		   },
		   executeUpdateDef : function(nam) {
			   var arg_array = ["-u", this.userName, "-p", this.password, "-S", this.hostName, "-arg", nam];
			   runCommand(cmdName, { args : arg_array });
			   
		   }
		   
	};
